import os
import getpass

path = f"/Users/{getpass.getuser()}/Desktop/Reverie-Lang/"
sdir = os.listdir(path)
file = ""
filen = 0
while not ".rev" in sdir[filen-1]:
    filen += 1
file = f"{path}{sdir[filen-1]}"
script = []
for line in open(file, "r+"):
    script.append(line)
print(file)
mainum = 0
numone = 0
val = []
line = ""
closers = ["\"", ")"]
while not mainum == len(script):
    mainum += 1
    line = script[mainum-1]
    if "system.write(" in line:
        numone = 14
        val.append("")
        while not line[numone] in closers:
            numone += 1
            val[len(val)-1] = f"{val[len(val)-1]}{line[numone-1]}"
        print(val[len(val)-1])
        val = []
