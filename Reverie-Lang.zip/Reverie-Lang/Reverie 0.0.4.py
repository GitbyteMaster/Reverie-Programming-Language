import os
import getpass
import time

path = f"/Users/{getpass.getuser()}/Desktop/Reverie-Lang/"
sdir = os.listdir(path)
file = ""
filen = 0
while not ".rev" in sdir[filen-1]:
    filen += 1
file = f"{path}{sdir[filen-1]}"
script = []
for line in open(file, "r+"):
    script.append(line)
print(file)
mainum = 0
numone = 0
val = []
line = ""
closers = ["\"", ")", ">"]
var = []
while not mainum == len(script):
    mainum += 1
    line = script[mainum-1]
    
    if "system.write(" in line:
        numone = 14
        val.append("")
        while not line[numone] in closers:
            numone += 1
            val[len(val)-1] = f"{val[len(val)-1]}{line[numone-1]}"
        if "\"" in line:
            print(val[len(val)-1])
        else:
            if val[0] in var:
                print(var[var.index(val[0])+1])
            else:
                print(f"[!] Variable Doesn't Exist ({mainum})")
        val = []

    if "var" in line:
        val.append("")
        val.append("")
        numone = 8
        while not line[numone] == " ":
            numone += 1
            val[0] = f"{val[0]}{line[numone-1]}"
        if not val[1] in var:
            var.append(val[0])
            var.append("")
            var.append(line[4]+line[5]+line[6])
        numone += 5
        while not line[numone] in closers:
            numone += 1
            val[len(val)-1] = f"{val[len(val)-1]}{line[numone-1]}"
        if "\"" in line:
            var[var.index(val[0])+1] = val[1]
        else:
            if ">" in line:
                if val[1] in var:
                    var[var.index(val[0])+1] = var[var.index(val[1])+1]
                else:
                    print(f"[!] Variable Doesn't Exist ({mainum})")
            else:
                var[var.index(val[0])+1] = val[1]
        

    if "time.delay(" in line:
        numone = 12
        val = []
        val.append("")
        while not line[numone] in closers:
            numone += 1
            val[len(val)-1] = f"{val[len(val)-1]}{line[numone-1]}"
        if "\"" in line:
            print(f"[!] Function Doesn't Support Str")
        else:
            if ">" in line:
                if val[len(val)-1] in var:
                    if var[var.index(val[0])+2] == "int":
                        time.sleep(int(var[var.index(val[0])+1]))

                    else:
                        print(f"[!] Function Only Supports Int")
                else:
                    print(f"[!] Variable Doesn't Exist ({mainum})")
            else:
                time.sleep(int(val[0]))
                
    if "system.input(" in line:
        numone = 14
        val = [""]
        while not line[numone] in closers:
            numone += 1
            val[len(val)-1] = f"{val[len(val)-1]}{line[numone-1]}"
        if "\"" == line[numone]:
            i = input(val[0])
        else:
            if ">" == line[numone]:
                i = input(var[var.index(val[len(val)-1])+1])
            else:
                i = input(val[0])
        while not line[numone] == "<":
            numone += 1
        val.append("")
        if line[numone] == "<":
            numone += 1
            while not line[numone] in closers:
                numone += 1
                val[1] = f"{val[1]}{line[numone-1]}"
            var[var.index(val[len(val)-1])+1] = i
    val = []

time.sleep(1)
